.. code:: ipython3

    # Installing necessary libraries
    !pip install yfinance matplotlib seaborn statsmodels scikit-learn
    
    # Imports
    import pandas as pd
    import numpy as np
    import yfinance as yf
    import matplotlib.pyplot as plt
    import seaborn as sns
    from datetime import datetime
    from statsmodels.tsa.seasonal import seasonal_decompose
    from statsmodels.graphics.tsaplots import plot_acf, plot_pacf
    from statsmodels.tsa.stattools import adfuller
    from statsmodels.tsa.arima.model import ARIMA
    import statsmodels.api as sm
    from statsmodels.tsa.holtwinters import ExponentialSmoothing
    
    from sklearn.metrics import mean_squared_error, mean_absolute_error
    import warnings
    warnings.filterwarnings("ignore")
    


.. parsed-literal::

    Requirement already satisfied: yfinance in c:\users\dell\appdata\local\programs\python\python313\lib\site-packages (0.2.66)
    Requirement already satisfied: matplotlib in c:\users\dell\appdata\local\programs\python\python313\lib\site-packages (3.10.1)
    Requirement already satisfied: seaborn in c:\users\dell\appdata\local\programs\python\python313\lib\site-packages (0.13.2)
    Requirement already satisfied: statsmodels in c:\users\dell\appdata\local\programs\python\python313\lib\site-packages (0.14.5)
    Requirement already satisfied: scikit-learn in c:\users\dell\appdata\local\programs\python\python313\lib\site-packages (1.7.2)
    Requirement already satisfied: pandas>=1.3.0 in c:\users\dell\appdata\local\programs\python\python313\lib\site-packages (from yfinance) (2.2.3)
    Requirement already satisfied: numpy>=1.16.5 in c:\users\dell\appdata\local\programs\python\python313\lib\site-packages (from yfinance) (2.2.5)
    Requirement already satisfied: requests>=2.31 in c:\users\dell\appdata\local\programs\python\python313\lib\site-packages (from yfinance) (2.32.4)
    Requirement already satisfied: multitasking>=0.0.7 in c:\users\dell\appdata\local\programs\python\python313\lib\site-packages (from yfinance) (0.0.12)
    Requirement already satisfied: platformdirs>=2.0.0 in c:\users\dell\appdata\local\programs\python\python313\lib\site-packages (from yfinance) (4.3.8)
    Requirement already satisfied: pytz>=2022.5 in c:\users\dell\appdata\local\programs\python\python313\lib\site-packages (from yfinance) (2025.2)
    Requirement already satisfied: frozendict>=2.3.4 in c:\users\dell\appdata\local\programs\python\python313\lib\site-packages (from yfinance) (2.4.6)
    Requirement already satisfied: peewee>=3.16.2 in c:\users\dell\appdata\local\programs\python\python313\lib\site-packages (from yfinance) (3.18.2)
    Requirement already satisfied: beautifulsoup4>=4.11.1 in c:\users\dell\appdata\local\programs\python\python313\lib\site-packages (from yfinance) (4.13.4)
    Requirement already satisfied: curl_cffi>=0.7 in c:\users\dell\appdata\local\programs\python\python313\lib\site-packages (from yfinance) (0.13.0)
    Requirement already satisfied: protobuf>=3.19.0 in c:\users\dell\appdata\local\programs\python\python313\lib\site-packages (from yfinance) (6.32.1)
    Requirement already satisfied: websockets>=13.0 in c:\users\dell\appdata\local\programs\python\python313\lib\site-packages (from yfinance) (15.0.1)
    Requirement already satisfied: contourpy>=1.0.1 in c:\users\dell\appdata\local\programs\python\python313\lib\site-packages (from matplotlib) (1.3.2)
    Requirement already satisfied: cycler>=0.10 in c:\users\dell\appdata\local\programs\python\python313\lib\site-packages (from matplotlib) (0.12.1)
    Requirement already satisfied: fonttools>=4.22.0 in c:\users\dell\appdata\local\programs\python\python313\lib\site-packages (from matplotlib) (4.57.0)
    Requirement already satisfied: kiwisolver>=1.3.1 in c:\users\dell\appdata\local\programs\python\python313\lib\site-packages (from matplotlib) (1.4.8)
    Requirement already satisfied: packaging>=20.0 in c:\users\dell\appdata\local\programs\python\python313\lib\site-packages (from matplotlib) (25.0)
    Requirement already satisfied: pillow>=8 in c:\users\dell\appdata\local\programs\python\python313\lib\site-packages (from matplotlib) (11.2.1)
    Requirement already satisfied: pyparsing>=2.3.1 in c:\users\dell\appdata\local\programs\python\python313\lib\site-packages (from matplotlib) (3.2.3)
    Requirement already satisfied: python-dateutil>=2.7 in c:\users\dell\appdata\local\programs\python\python313\lib\site-packages (from matplotlib) (2.9.0.post0)
    Requirement already satisfied: scipy!=1.9.2,>=1.8 in c:\users\dell\appdata\local\programs\python\python313\lib\site-packages (from statsmodels) (1.15.2)
    Requirement already satisfied: patsy>=0.5.6 in c:\users\dell\appdata\local\programs\python\python313\lib\site-packages (from statsmodels) (1.0.1)
    Requirement already satisfied: joblib>=1.2.0 in c:\users\dell\appdata\local\programs\python\python313\lib\site-packages (from scikit-learn) (1.5.2)
    Requirement already satisfied: threadpoolctl>=3.1.0 in c:\users\dell\appdata\local\programs\python\python313\lib\site-packages (from scikit-learn) (3.6.0)
    Requirement already satisfied: soupsieve>1.2 in c:\users\dell\appdata\local\programs\python\python313\lib\site-packages (from beautifulsoup4>=4.11.1->yfinance) (2.7)
    Requirement already satisfied: typing-extensions>=4.0.0 in c:\users\dell\appdata\local\programs\python\python313\lib\site-packages (from beautifulsoup4>=4.11.1->yfinance) (4.14.1)
    Requirement already satisfied: cffi>=1.12.0 in c:\users\dell\appdata\local\programs\python\python313\lib\site-packages (from curl_cffi>=0.7->yfinance) (1.17.1)
    Requirement already satisfied: certifi>=2024.2.2 in c:\users\dell\appdata\local\programs\python\python313\lib\site-packages (from curl_cffi>=0.7->yfinance) (2025.7.14)
    Requirement already satisfied: pycparser in c:\users\dell\appdata\local\programs\python\python313\lib\site-packages (from cffi>=1.12.0->curl_cffi>=0.7->yfinance) (2.22)
    Requirement already satisfied: tzdata>=2022.7 in c:\users\dell\appdata\local\programs\python\python313\lib\site-packages (from pandas>=1.3.0->yfinance) (2025.2)
    Requirement already satisfied: six>=1.5 in c:\users\dell\appdata\local\programs\python\python313\lib\site-packages (from python-dateutil>=2.7->matplotlib) (1.17.0)
    Requirement already satisfied: charset_normalizer<4,>=2 in c:\users\dell\appdata\local\programs\python\python313\lib\site-packages (from requests>=2.31->yfinance) (3.4.2)
    Requirement already satisfied: idna<4,>=2.5 in c:\users\dell\appdata\local\programs\python\python313\lib\site-packages (from requests>=2.31->yfinance) (3.10)
    Requirement already satisfied: urllib3<3,>=1.21.1 in c:\users\dell\appdata\local\programs\python\python313\lib\site-packages (from requests>=2.31->yfinance) (2.5.0)
    

.. parsed-literal::

    
    [notice] A new release of pip is available: 25.1.1 -> 25.2
    [notice] To update, run: python.exe -m pip install --upgrade pip
    

.. code:: ipython3

    # Download data for Amazon (ticker 'AMZN')
    start_date = '2012-01-01'
    end_date = '2024-10-31'
    
    data = yf.download('AMZN', start=start_date, end=end_date, progress=False)
    data = data.resample('ME').last()  # Month End
    data = data[['Close']]
    data.dropna(inplace=True)
    print(data.head())
    print(data.shape)


.. parsed-literal::

    Price         Close
    Ticker         AMZN
    Date               
    2012-01-31   9.7220
    2012-02-29   8.9845
    2012-03-31  10.1255
    2012-04-30  11.5950
    2012-05-31  10.6455
    (154, 1)
    

.. code:: ipython3

    # plotting the monthly closing prices
    
    plt.figure(figsize=(14, 8))
    plt.plot(data['Close'], label='Monthly Close Price')
    plt.title('Amazon Monthly Close Prices')
    plt.xlabel('Date')
    plt.ylabel('Price (USD)')
    plt.legend()
    plt.show()
    



.. image:: output_2_0.png


.. code:: ipython3

    # calculating 3, 6, 12-month moving averages
    
    data['3_month_MA'] = data['Close'].rolling(window=3).mean()
    data['6_month_MA'] = data['Close'].rolling(window=6).mean()
    data['12_month_MA'] = data['Close'].rolling(window=12).mean()
    
    plt.figure(figsize=(14, 8))
    plt.plot(data['Close'], label='Monthly Close Price')
    plt.plot(data['3_month_MA'], label='3 Month MA')
    plt.plot(data['6_month_MA'], label='6 Month MA')
    plt.plot(data['12_month_MA'], label='12 Month MA')
    plt.title('Amazon Closing Price with Moving Averages')
    plt.xlabel('Date')
    plt.ylabel('Price (USD)')
    plt.legend()
    plt.show()
    



.. image:: output_3_0.png


.. code:: ipython3

    # Augmented Dickey-Fuller Test for checking stationarity
    
    def adf_test(series):
        result = adfuller(series, autolag='AIC')
        print('ADF Statistic:', result[0])
        print('p-value:', result[1])
        if result[1] <= 0.05:
            print("Series is Stationary")
        else:
            print("Series is Non-Stationary")
    
    adf_test(data['Close'])
    
    # First differencing if non-stationary
    data['Close_diff'] = data['Close'].diff().dropna()
    adf_test(data['Close_diff'].dropna())
    


.. parsed-literal::

    ADF Statistic: -0.45822203358685243
    p-value: 0.8999145949252203
    Series is Non-Stationary
    ADF Statistic: -4.92928149571886
    p-value: 3.0575157318213284e-05
    Series is Stationary
    

.. code:: ipython3

    
    # Seasonal decomposition of the time series
    
    decompose_result = seasonal_decompose(data['Close'], model='multiplicative', period=12)
    decompose_result.plot()
    plt.show()
    



.. image:: output_5_0.png


.. code:: ipython3

    # Plot ACF and PACF Before differencing
    
    plot_acf(data['Close'].dropna(), lags=20)
    plt.show()
    
    plot_pacf(data['Close'].dropna(), lags=20)
    plt.show()
    
    # Plot ACF and PACF After differencing
    plot_acf(data['Close_diff'].dropna(), lags=20)
    plt.show()
    
    plot_pacf(data['Close_diff'].dropna(), lags=20)
    plt.show()
    



.. image:: output_6_0.png



.. image:: output_6_1.png



.. image:: output_6_2.png



.. image:: output_6_3.png


.. code:: ipython3

    # Train-Test split 
    
    train_data = data['Close'][:int(len(data)*0.8)]
    test_data = data['Close'][int(len(data)*0.8):]
    

.. code:: ipython3

    
    # Automatic SARIMA Fitting with Grid Search
    
    from statsmodels.tsa.statespace.sarimax import SARIMAX
    
    def auto_sarima(train_data, seasonal_period=12):
        best_aic = np.inf
        best_order = None
        best_seasonal_order = None
        best_model = None
    
        for p in range(3):
            for d in range(2):
                for q in range(3):
                    for P in range(3):
                        for D in range(2):
                            for Q in range(3):
                                try:
                                    model = SARIMAX(train_data,
                                                    order=(p,d,q),
                                                    seasonal_order=(P,D,Q,seasonal_period),
                                                    enforce_stationarity=False,
                                                    enforce_invertibility=False)
                                    results = model.fit(disp=False)
                                    if results.aic < best_aic:
                                        best_aic = results.aic
                                        best_order = (p,d,q)
                                        best_seasonal_order = (P,D,Q,seasonal_period)
                                        best_model = results
                                        print(f"SARIMA Order: {best_order}, Seasonal Order: {best_seasonal_order}, AIC: {best_aic}")
                                except:
                                    continue
        print(f"\nBest SARIMA Order: {best_order}, Seasonal Order: {best_seasonal_order}, AIC: {best_aic}")
        return best_model
    
    sarima_model = auto_sarima(train_data)
    


.. parsed-literal::

    SARIMA Order: (0, 0, 0), Seasonal Order: (0, 0, 0, 12), AIC: 1431.4100681964758
    SARIMA Order: (0, 0, 0), Seasonal Order: (0, 0, 1, 12), AIC: 1202.7721562942213
    SARIMA Order: (0, 0, 0), Seasonal Order: (0, 0, 2, 12), AIC: 1039.3761816991882
    SARIMA Order: (0, 0, 0), Seasonal Order: (0, 1, 0, 12), AIC: 1028.3367587220853
    SARIMA Order: (0, 0, 0), Seasonal Order: (0, 1, 1, 12), AIC: 924.2401597773073
    SARIMA Order: (0, 0, 0), Seasonal Order: (0, 1, 2, 12), AIC: 797.386148549626
    SARIMA Order: (0, 0, 0), Seasonal Order: (1, 1, 2, 12), AIC: 750.6146527415124
    SARIMA Order: (0, 0, 0), Seasonal Order: (2, 1, 1, 12), AIC: 716.8693267692045
    SARIMA Order: (0, 0, 0), Seasonal Order: (2, 1, 2, 12), AIC: 710.0263505149162
    SARIMA Order: (0, 0, 1), Seasonal Order: (0, 1, 2, 12), AIC: 709.644900061786
    SARIMA Order: (0, 0, 1), Seasonal Order: (1, 1, 2, 12), AIC: 674.8874101161259
    SARIMA Order: (0, 0, 1), Seasonal Order: (2, 1, 1, 12), AIC: 668.5355703745148
    SARIMA Order: (0, 0, 2), Seasonal Order: (0, 1, 2, 12), AIC: 659.6907524181863
    SARIMA Order: (0, 0, 2), Seasonal Order: (1, 1, 2, 12), AIC: 633.4663658223136
    SARIMA Order: (0, 0, 2), Seasonal Order: (2, 1, 2, 12), AIC: 625.798601142312
    SARIMA Order: (0, 1, 0), Seasonal Order: (0, 1, 2, 12), AIC: 582.86939920409
    SARIMA Order: (0, 1, 0), Seasonal Order: (1, 1, 2, 12), AIC: 580.7520067634168
    SARIMA Order: (0, 1, 1), Seasonal Order: (0, 1, 2, 12), AIC: 579.0598094480508
    SARIMA Order: (0, 1, 1), Seasonal Order: (1, 1, 2, 12), AIC: 576.678230697801
    SARIMA Order: (0, 1, 2), Seasonal Order: (0, 1, 2, 12), AIC: 574.5546156306181
    SARIMA Order: (0, 1, 2), Seasonal Order: (1, 1, 2, 12), AIC: 572.2540661399797
    SARIMA Order: (2, 1, 2), Seasonal Order: (2, 1, 2, 12), AIC: 568.7452246075285
    
    Best SARIMA Order: (2, 1, 2), Seasonal Order: (2, 1, 2, 12), AIC: 568.7452246075285
    

.. code:: ipython3

    # SARIMA Forecasting
    
    sarima_forecast = sarima_model.predict(start=len(train_data), end=len(train_data) + len(test_data) - 1, dynamic=False)

.. code:: ipython3

    # Plot SARIMA results
    plt.figure(figsize=(14, 8))
    plt.plot(train_data, label='Train')
    plt.plot(test_data, label='Test')
    plt.plot(sarima_forecast, label='SARIMA Forecast', color='orange')
    plt.title('Amazon Stock Price Prediction (SARIMA)')
    plt.xlabel('Date')
    plt.ylabel('Price (USD)')
    plt.legend()
    plt.show()



.. image:: output_10_0.png


.. code:: ipython3

    # RMSE & MAE
    
    from sklearn.metrics import mean_squared_error, mean_absolute_error
    import numpy as np
    
    # Convert Series to numpy arrays (ensure same shape)
    y_true = test_data.values
    y_pred = sarima_forecast.values
    
    # RMSE manually
    sarima_rmse = np.sqrt(mean_squared_error(y_true, y_pred))
    sarima_mae = mean_absolute_error(y_true, y_pred)
    
    print(f'SARIMA RMSE: {sarima_rmse}')
    print(f'SARIMA MAE: {sarima_mae}')


.. parsed-literal::

    SARIMA RMSE: 79.14674309268771
    SARIMA MAE: 75.56967340707243
    

.. code:: ipython3

    # Exponential Smoothing (Holt-Winters Method)
    
    def exponential_smoothing(train_data, test_data):
        model = ExponentialSmoothing(train_data, trend='mul', seasonal='mul', seasonal_periods=12)
        model_fit = model.fit()
        forecast = model_fit.forecast(len(test_data))
        
        plt.figure(figsize=(14, 8))
        plt.plot(train_data, label='Train')
        plt.plot(test_data, label='Test')
        plt.plot(forecast, label='Exponential Smoothing Forecast', color='green')
        plt.title('Exponential Smoothing Forecast')
        plt.xlabel('Date')
        plt.ylabel('Price (USD)')
        plt.legend()
        plt.show()
        
        return forecast
    
    
    # Apply Exponential Smoothing Model    
    
    exp_smoothing_forecast = exponential_smoothing(train_data, test_data)



.. image:: output_12_0.png


.. code:: ipython3

    # Calculate RMSE and MAE for Exponential Smoothing
    
    exp_smoothing_rmse = np.sqrt(mean_squared_error(test_data.values, exp_smoothing_forecast.values))
    exp_smoothing_mae = mean_absolute_error(test_data.values, exp_smoothing_forecast.values)
    
    print(f'Exponential Smoothing RMSE: {exp_smoothing_rmse}')
    print(f'Exponential Smoothing MAE: {exp_smoothing_mae}')


.. parsed-literal::

    Exponential Smoothing RMSE: 92.87374533235226
    Exponential Smoothing MAE: 91.13782586145804
    

.. code:: ipython3

    
    # Comparison of Models
    
    if sarima_rmse < exp_smoothing_rmse:
        print("SARIMA performs better based on RMSE.")
    else:
        print("Exponential Smoothing performs better based on RMSE.")
    
    if sarima_mae < exp_smoothing_mae:
        print("SARIMA performs better based on MAE.")
    else:
        print("Exponential Smoothing performs better based on MAE.")
    


.. parsed-literal::

    SARIMA performs better based on RMSE.
    SARIMA performs better based on MAE.
    

